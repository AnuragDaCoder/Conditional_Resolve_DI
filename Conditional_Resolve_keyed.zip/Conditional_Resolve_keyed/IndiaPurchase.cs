﻿using AddKeyMethods;
using Microsoft.Extensions.DependencyInjection;
using System.Web.Http;

namespace ConsoleApp1
{
    public class IndiaPurchase
    {
        private readonly ITaxCalculator _taxCalculator;

        public IndiaPurchase([FromKeyedServices(Locations.India)]ITaxCalculator taxCalculator)
        {
            _taxCalculator = taxCalculator;
        }

        [HttpGet]
        public int CheckOut()
        {
            var total = _taxCalculator.CalculateTax() + 200;
            return total;
        }
    }
}
