﻿using AddKeyMethods;
using Microsoft.Extensions.DependencyInjection;
using System.Web.Http;

namespace ConsoleApp1
{
    public class MixPurchase
    {
        private readonly ITaxCalculator _indtaxCalculator;
        private readonly ITaxCalculator _uAEtaxCalculator;

        public MixPurchase([FromKeyedServices(Locations.India)]ITaxCalculator indtaxCalculator, [FromKeyedServices(Locations.UAE)] ITaxCalculator uAEtaxCalculator)
        {
            _indtaxCalculator = indtaxCalculator;
            _uAEtaxCalculator = uAEtaxCalculator;
        }

        [HttpGet]
        public int CheckOut()
        {
            var total = _indtaxCalculator.CalculateTax() + 200 + _uAEtaxCalculator.CalculateTax() + 2;
            return total;
        }
    }
}
