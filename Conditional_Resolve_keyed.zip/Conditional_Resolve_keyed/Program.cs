﻿using AddKeyMethods;
using ConsoleApp1;
using Microsoft.Extensions.DependencyInjection;

var collection = new ServiceCollection();

collection.AddKeyedSingleton<ITaxCalculator, IndiaTaxCalculator>(Locations.India);
collection.AddKeyedSingleton<ITaxCalculator, UAETaxCalculator>(Locations.UAE);
collection.AddScoped<IndiaPurchase>();
collection.AddScoped<UAEPurchase>();
collection.AddScoped<MixPurchase>();
var provider = collection.BuildServiceProvider();

//ITaxCalculator calculator = provider.GetKeyedService<ITaxCalculator>(Locations.India);
Console.Clear();
//Console.WriteLine($"Your tax rate is {calculator.CalculateTax()}");


//..........INDIA...............................
var purchase = provider.GetService<IndiaPurchase>();
var total = purchase?.CheckOut();
Console.WriteLine(total);
//..............................................


//..........UAE..............................
var uaePurchase = provider.GetService<UAEPurchase>();
var totalUAEPrice = uaePurchase?.CheckOut();
Console.WriteLine(totalUAEPrice);
//..............................................



//.............MIX........

var mixPurchase = provider.GetService<MixPurchase>();
var totalMixPrice = mixPurchase?.CheckOut();
Console.WriteLine(totalMixPrice);

//.......................


Console.ReadKey();