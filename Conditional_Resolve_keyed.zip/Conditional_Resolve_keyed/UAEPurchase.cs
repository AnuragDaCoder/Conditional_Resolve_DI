﻿using AddKeyMethods;
using Microsoft.Extensions.DependencyInjection;
using System.Web.Http;

namespace ConsoleApp1
{
    public class UAEPurchase
    {
        private readonly ITaxCalculator _taxCalculator;

        public UAEPurchase([FromKeyedServices(Locations.UAE)]ITaxCalculator taxCalculator)
        {
            _taxCalculator = taxCalculator;
        }

        [HttpGet]
        public int CheckOut()
        {
            var total = _taxCalculator.CalculateTax() + 0;
            return total;
        }
    }
}
