﻿//// See https://aka.ms/new-console-template for more information
//using ConsoleApp1;
//using Microsoft.Extensions.DependencyInjection;
//using System.Security.Authentication.ExtendedProtection;


//Console.WriteLine("Hello, World!");
//Console.Clear();

////step 1
////ServiceCollection : IServiceCollection
//var collection = new ServiceCollection();

////step 2 - register classes..
//collection.AddScoped<IndiaTaxCalculator>();
//collection.AddScoped<UAETaxCalculator>();

////step 3
//collection.AddScoped<Func<Locations, ITaxCalculator>>(
//    ServiceProvider => key =>
//    {
//        switch (key)
//        {
//            case Locations.India: return ServiceProvider.GetService<IndiaTaxCalculator>();
//            case Locations.UAE: return ServiceProvider.GetService<UAETaxCalculator>();
//            default: return null;
//        }
//    }
//);

//collection.AddScoped<Purchase>();

//var provider = collection.BuildServiceProvider();

//var purchase = provider.GetService<Purchase>();
//var total =purchase?.CheckOut(Locations.UAE);
//Console.WriteLine(total);
