﻿using AddKeyMethods;
using ConsoleApp1;
using Microsoft.Extensions.DependencyInjection;

var collection = new ServiceCollection();

collection.AddKeyedSingleton<ITaxCalculator, IndiaTaxCalculator>(Locations.India);
collection.AddKeyedSingleton<ITaxCalculator, UAETaxCalculator>(Locations.UAE);
collection.AddScoped<Purchase>();
var provider = collection.BuildServiceProvider();

//ITaxCalculator calculator = provider.GetKeyedService<ITaxCalculator>(Locations.India);
Console.Clear();
//Console.WriteLine($"Your tax rate is {calculator.CalculateTax()}");


var purchase = provider.GetService<Purchase>();
var total = purchase?.CheckOut();


Console.ReadKey();