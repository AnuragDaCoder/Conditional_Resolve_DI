﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddKeyMethods
{
    public interface ITaxCalculator
    {
        int CalculateTax();
    }

    public class IndiaTaxCalculator : ITaxCalculator
    {
        public int CalculateTax() { return 30; }
        
    }

    public class UAETaxCalculator : ITaxCalculator
    {
        public int CalculateTax() { return 0; }

    }

    public enum Locations
    {
        India,
        UAE,
        USA
    }
}
