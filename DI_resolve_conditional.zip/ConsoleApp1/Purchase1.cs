﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ConsoleApp1
//{
//    public class Purchase
//    {
//        private readonly Func<Locations, ITaxCalculator> _accessor;

//        public Purchase(Func<Locations, ITaxCalculator> accessor)
//        {
//            _accessor = accessor;
//        }

//        public int CheckOut(Locations locations)
//        {
//            var countryTax = _accessor(locations);

//            var total = countryTax.CalculateTax() + 200;
//            return total;
//        }
//    }
//}
