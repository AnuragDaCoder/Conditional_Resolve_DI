﻿using AddKeyMethods;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace ConsoleApp1
{
    public class Purchase
    {
        private readonly ITaxCalculator _taxCalculator;

        public Purchase([FromKeyedServices(Locations.India)]ITaxCalculator taxCalculator)
        {
            _taxCalculator = taxCalculator;
        }

        [HttpGet]
        public int CheckOut()
        {
            var total = _taxCalculator.CalculateTax() + 200;
            return total;
        }
    }
}
